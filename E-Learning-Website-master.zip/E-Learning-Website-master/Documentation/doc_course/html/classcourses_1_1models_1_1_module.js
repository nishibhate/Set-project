var classcourses_1_1models_1_1_module =
[
    [ "Meta", "classcourses_1_1models_1_1_module_1_1_meta.html", null ],
    [ "__str__", "classcourses_1_1models_1_1_module.html#acd58a6f72b5194b8fb823ffeffc864b0", null ]
];