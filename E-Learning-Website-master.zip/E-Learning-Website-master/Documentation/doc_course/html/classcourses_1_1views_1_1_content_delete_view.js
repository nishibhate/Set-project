var classcourses_1_1views_1_1_content_delete_view =
[
    [ "post", "classcourses_1_1views_1_1_content_delete_view.html#a0c50fd6c77c6a0af14f45f3f067d5dba", null ]
];