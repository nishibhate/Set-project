var annotated_dup =
[
    [ "courses", "namespacecourses.html", "namespacecourses" ]
];