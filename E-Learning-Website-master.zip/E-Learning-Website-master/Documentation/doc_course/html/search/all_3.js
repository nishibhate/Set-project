var searchData=
[
  ['description_33',['description',['../classcourses_1_1models_1_1_module.html#a5354dfaf2c87abcbefd46be40ca38c73',1,'courses::models::Module']]],
  ['dispatch_34',['dispatch',['../classcourses_1_1views_1_1_course_module_update_view.html#a4cdc9d2877f5a604b56a46e265847320',1,'courses.views.CourseModuleUpdateView.dispatch()'],['../namespacecourses_1_1views.html#a0eea71301b59232165bbef6159806ed9',1,'courses.views.dispatch()']]]
];
