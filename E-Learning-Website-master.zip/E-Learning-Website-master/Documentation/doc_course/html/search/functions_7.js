var searchData=
[
  ['test_5fcourse_5fcontent_171',['test_course_content',['../classcourses_1_1tests_1_1_course_model_test.html#aa590ed3e4020982486beb2aad50b11f3',1,'courses::tests::CourseModelTest']]],
  ['test_5fstudent_5ffield_172',['test_student_field',['../classcourses_1_1tests_1_1_course_model_test.html#a48ad111af0a198ed228a266dd25e7e9f',1,'courses::tests::CourseModelTest']]],
  ['test_5fsubject_5fcontent_173',['test_subject_content',['../classcourses_1_1tests_1_1_course_model_test.html#a319f855c5c97d83fc03d3deeb33ba2b9',1,'courses::tests::CourseModelTest']]],
  ['test_5fuser_174',['test_user',['../classcourses_1_1tests_1_1_course_model_test.html#a870653c999493421bf3f7b49fa647dca',1,'courses::tests::CourseModelTest']]],
  ['test_5fview_5furl_5fexists_5fat_5fproper_5flocation_175',['test_view_url_exists_at_proper_location',['../classcourses_1_1tests_1_1_course_page_view_test.html#ad6875be887c9f167d99ae3ec6267de78',1,'courses::tests::CoursePageViewTest']]],
  ['test_5fview_5fuses_5fcorrect_5ftemplates_176',['test_view_uses_correct_templates',['../classcourses_1_1tests_1_1_course_page_view_test.html#ab67e570a7487212848fc239c5aa85f18',1,'courses::tests::CoursePageViewTest']]]
];
