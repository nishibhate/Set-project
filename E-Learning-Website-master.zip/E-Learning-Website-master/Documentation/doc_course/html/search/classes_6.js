var searchData=
[
  ['text_137',['Text',['../classcourses_1_1models_1_1_text.html',1,'courses::models']]]
];
