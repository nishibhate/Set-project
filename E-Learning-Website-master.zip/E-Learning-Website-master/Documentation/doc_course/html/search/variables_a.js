var searchData=
[
  ['search_5ffields_203',['search_fields',['../classcourses_1_1admin_1_1_course_admin.html#a3ce61dc2cb30bb68bb3eb23a3829c28c',1,'courses::admin::CourseAdmin']]],
  ['slug_204',['slug',['../classcourses_1_1models_1_1_subject.html#a2de292c06fa3ebf1af63400cc0964c86',1,'courses.models.Subject.slug()'],['../classcourses_1_1models_1_1_course.html#ad1d5875648b9c469132d166071920ae4',1,'courses.models.Course.slug()']]],
  ['sub1_205',['sub1',['../classcourses_1_1tests_1_1_course_model_test.html#a1abd865082befc1f2a25ab2895abc232',1,'courses.tests.CourseModelTest.sub1()'],['../classcourses_1_1tests_1_1_course_page_view_test.html#ad87782df0950a5be8da344fa102906e6',1,'courses.tests.CoursePageViewTest.sub1()']]],
  ['subject_206',['subject',['../classcourses_1_1models_1_1_course.html#abb6e701f8df4d67a8f5f74ef6a8fa3ac',1,'courses::models::Course']]],
  ['success_5furl_207',['success_url',['../classcourses_1_1views_1_1_owner_course_edit_mixin.html#a903ba65a9da41de908539febd67a410b',1,'courses.views.OwnerCourseEditMixin.success_url()'],['../classcourses_1_1views_1_1_course_delete_view.html#a2af0fad5591edcca3c8b0b5ed8aa3dff',1,'courses.views.CourseDeleteView.success_url()']]]
];
