var searchData=
[
  ['urls_2epy_155',['urls.py',['../urls_8py.html',1,'']]]
];
