var searchData=
[
  ['file_120',['File',['../classcourses_1_1models_1_1_file.html',1,'courses::models']]]
];
