var searchData=
[
  ['permission_5frequired_201',['permission_required',['../classcourses_1_1views_1_1_course_delete_view.html#a336ab1fa29fc1a17d1a2794898097752',1,'courses::views::CourseDeleteView']]],
  ['prepopulated_5ffields_202',['prepopulated_fields',['../classcourses_1_1admin_1_1_subject_admin.html#a63082392e53e8ebb7f5e17b540502743',1,'courses.admin.SubjectAdmin.prepopulated_fields()'],['../classcourses_1_1admin_1_1_course_admin.html#af79821e8fb05c5d6c2db0e691f8a607f',1,'courses.admin.CourseAdmin.prepopulated_fields()']]]
];
