var searchData=
[
  ['list_5fdisplay_51',['list_display',['../classcourses_1_1admin_1_1_subject_admin.html#a0a8852bb57f2a362a5478c7b5d2d4437',1,'courses.admin.SubjectAdmin.list_display()'],['../classcourses_1_1admin_1_1_course_admin.html#a14fd398aa151d37a0f7ba1b119cee993',1,'courses.admin.CourseAdmin.list_display()']]],
  ['list_5ffilter_52',['list_filter',['../classcourses_1_1admin_1_1_course_admin.html#a8ac53c23fa57406646830905f313858a',1,'courses::admin::CourseAdmin']]]
];
