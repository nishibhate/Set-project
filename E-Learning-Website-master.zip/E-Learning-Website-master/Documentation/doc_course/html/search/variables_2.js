var searchData=
[
  ['description_183',['description',['../classcourses_1_1models_1_1_module.html#a5354dfaf2c87abcbefd46be40ca38c73',1,'courses::models::Module']]]
];
