var searchData=
[
  ['name_194',['name',['../classcourses_1_1apps_1_1_courses_config.html#aa9d8ba01b9ecf36c212bb500e42e2fc9',1,'courses::apps::CoursesConfig']]]
];
