var searchData=
[
  ['dispatch_159',['dispatch',['../classcourses_1_1views_1_1_course_module_update_view.html#a4cdc9d2877f5a604b56a46e265847320',1,'courses.views.CourseModuleUpdateView.dispatch()'],['../namespacecourses_1_1views.html#a0eea71301b59232165bbef6159806ed9',1,'courses.views.dispatch()']]]
];
