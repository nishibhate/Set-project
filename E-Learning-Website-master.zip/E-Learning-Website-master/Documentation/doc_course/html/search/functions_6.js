var searchData=
[
  ['setup_170',['setup',['../classcourses_1_1tests_1_1_course_page_view_test.html#a9a0d63ebc4cd50302f04b60c7dcc7de3',1,'courses.tests.CoursePageViewTest.setup()'],['../classcourses_1_1tests_1_1_course_model_test.html#adf01411551988dc115fe27aa8919aa3a',1,'courses.tests.CourseModelTest.setUp()']]]
];
