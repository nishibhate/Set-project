var searchData=
[
  ['u1_97',['u1',['../classcourses_1_1tests_1_1_course_model_test.html#a9aaf67ba044f847815c064826231e5d1',1,'courses.tests.CourseModelTest.u1()'],['../classcourses_1_1tests_1_1_course_page_view_test.html#a71005eb4cac8ad89f812b304608c9e50',1,'courses.tests.CoursePageViewTest.u1()']]],
  ['u2_98',['u2',['../classcourses_1_1tests_1_1_course_model_test.html#a91b7015095aed553a44b96f9e29fb447',1,'courses.tests.CourseModelTest.u2()'],['../classcourses_1_1tests_1_1_course_page_view_test.html#ac15c19dd7cb0f8d65cfc626185b80024',1,'courses.tests.CoursePageViewTest.u2()']]],
  ['updated_99',['updated',['../classcourses_1_1models_1_1_item_base.html#a2dc3197bef9ab97af1c1582b88b91442',1,'courses::models::ItemBase']]],
  ['url_100',['url',['../classcourses_1_1models_1_1_video.html#a9614906e6dc935f4737d4dcc7ad43619',1,'courses::models::Video']]],
  ['urlpatterns_101',['urlpatterns',['../namespacecourses_1_1urls.html#aacc66e14cddc63727182685f921b8726',1,'courses::urls']]],
  ['urls_2epy_102',['urls.py',['../urls_8py.html',1,'']]]
];
