var searchData=
[
  ['search_5ffields_79',['search_fields',['../classcourses_1_1admin_1_1_course_admin.html#a3ce61dc2cb30bb68bb3eb23a3829c28c',1,'courses::admin::CourseAdmin']]],
  ['setup_80',['setup',['../classcourses_1_1tests_1_1_course_page_view_test.html#a9a0d63ebc4cd50302f04b60c7dcc7de3',1,'courses.tests.CoursePageViewTest.setup()'],['../classcourses_1_1tests_1_1_course_model_test.html#adf01411551988dc115fe27aa8919aa3a',1,'courses.tests.CourseModelTest.setUp()']]],
  ['slug_81',['slug',['../classcourses_1_1models_1_1_subject.html#a2de292c06fa3ebf1af63400cc0964c86',1,'courses.models.Subject.slug()'],['../classcourses_1_1models_1_1_course.html#ad1d5875648b9c469132d166071920ae4',1,'courses.models.Course.slug()']]],
  ['sub1_82',['sub1',['../classcourses_1_1tests_1_1_course_model_test.html#a1abd865082befc1f2a25ab2895abc232',1,'courses.tests.CourseModelTest.sub1()'],['../classcourses_1_1tests_1_1_course_page_view_test.html#ad87782df0950a5be8da344fa102906e6',1,'courses.tests.CoursePageViewTest.sub1()']]],
  ['subject_83',['Subject',['../classcourses_1_1models_1_1_subject.html',1,'courses.models.Subject'],['../classcourses_1_1models_1_1_course.html#abb6e701f8df4d67a8f5f74ef6a8fa3ac',1,'courses.models.Course.subject()']]],
  ['subjectadmin_84',['SubjectAdmin',['../classcourses_1_1admin_1_1_subject_admin.html',1,'courses::admin']]],
  ['subjectlistview_85',['SubjectListView',['../classcourses_1_1views_1_1_subject_list_view.html',1,'courses::views']]],
  ['success_5furl_86',['success_url',['../classcourses_1_1views_1_1_owner_course_edit_mixin.html#a903ba65a9da41de908539febd67a410b',1,'courses.views.OwnerCourseEditMixin.success_url()'],['../classcourses_1_1views_1_1_course_delete_view.html#a2af0fad5591edcca3c8b0b5ed8aa3dff',1,'courses.views.CourseDeleteView.success_url()']]]
];
