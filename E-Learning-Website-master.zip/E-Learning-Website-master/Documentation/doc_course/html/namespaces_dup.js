var namespaces_dup =
[
    [ "courses", "namespacecourses.html", "namespacecourses" ]
];