var namespacecourses_1_1apps =
[
    [ "CoursesConfig", "classcourses_1_1apps_1_1_courses_config.html", null ]
];