var classcourses_1_1models_1_1_subject =
[
    [ "Meta", "classcourses_1_1models_1_1_subject_1_1_meta.html", null ],
    [ "__str__", "classcourses_1_1models_1_1_subject.html#a326739e11e67a601be582d82d0c53b75", null ]
];