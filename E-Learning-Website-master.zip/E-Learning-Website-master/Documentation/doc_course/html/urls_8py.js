var urls_8py =
[
    [ "urlpatterns", "urls_8py.html#aacc66e14cddc63727182685f921b8726", null ]
];