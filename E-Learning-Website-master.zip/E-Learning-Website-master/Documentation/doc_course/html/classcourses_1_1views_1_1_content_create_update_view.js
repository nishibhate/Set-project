var classcourses_1_1views_1_1_content_create_update_view =
[
    [ "get_form", "classcourses_1_1views_1_1_content_create_update_view.html#a32868bf385f3af28bbe1194b84864335", null ],
    [ "get_model", "classcourses_1_1views_1_1_content_create_update_view.html#a666059ae7a077a086e84643b9b4df094", null ]
];