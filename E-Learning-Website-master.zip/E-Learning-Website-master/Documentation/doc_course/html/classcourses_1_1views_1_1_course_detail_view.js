var classcourses_1_1views_1_1_course_detail_view =
[
    [ "get_context_data", "classcourses_1_1views_1_1_course_detail_view.html#ad52dc8948c495c734b0cccb356691b69", null ]
];