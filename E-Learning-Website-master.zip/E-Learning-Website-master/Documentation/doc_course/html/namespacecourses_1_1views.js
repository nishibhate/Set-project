var namespacecourses_1_1views =
[
    [ "ContentCreateUpdateView", "classcourses_1_1views_1_1_content_create_update_view.html", "classcourses_1_1views_1_1_content_create_update_view" ],
    [ "ContentDeleteView", "classcourses_1_1views_1_1_content_delete_view.html", "classcourses_1_1views_1_1_content_delete_view" ],
    [ "ContentOrderView", "classcourses_1_1views_1_1_content_order_view.html", "classcourses_1_1views_1_1_content_order_view" ],
    [ "CourseCreateView", "classcourses_1_1views_1_1_course_create_view.html", null ],
    [ "CourseDeleteView", "classcourses_1_1views_1_1_course_delete_view.html", null ],
    [ "CourseDetailView", "classcourses_1_1views_1_1_course_detail_view.html", "classcourses_1_1views_1_1_course_detail_view" ],
    [ "CourseListView", "classcourses_1_1views_1_1_course_list_view.html", "classcourses_1_1views_1_1_course_list_view" ],
    [ "CourseModuleUpdateView", "classcourses_1_1views_1_1_course_module_update_view.html", "classcourses_1_1views_1_1_course_module_update_view" ],
    [ "CourseUpdateView", "classcourses_1_1views_1_1_course_update_view.html", null ],
    [ "ManageCourseListView", "classcourses_1_1views_1_1_manage_course_list_view.html", null ],
    [ "ModuleContentListView", "classcourses_1_1views_1_1_module_content_list_view.html", "classcourses_1_1views_1_1_module_content_list_view" ],
    [ "ModuleOrderView", "classcourses_1_1views_1_1_module_order_view.html", "classcourses_1_1views_1_1_module_order_view" ],
    [ "OwnerCourseEditMixin", "classcourses_1_1views_1_1_owner_course_edit_mixin.html", null ],
    [ "OwnerCourseMixin", "classcourses_1_1views_1_1_owner_course_mixin.html", null ],
    [ "OwnerEditMixin", "classcourses_1_1views_1_1_owner_edit_mixin.html", "classcourses_1_1views_1_1_owner_edit_mixin" ],
    [ "OwnerMixin", "classcourses_1_1views_1_1_owner_mixin.html", "classcourses_1_1views_1_1_owner_mixin" ],
    [ "SubjectListView", "classcourses_1_1views_1_1_subject_list_view.html", null ]
];