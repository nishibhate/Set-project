var classcourses_1_1views_1_1_course_list_view =
[
    [ "get", "classcourses_1_1views_1_1_course_list_view.html#ac6aa314a0a8d0667bdbdfa6af56833d5", null ]
];