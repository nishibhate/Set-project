var classcourses_1_1views_1_1_module_content_list_view =
[
    [ "get", "classcourses_1_1views_1_1_module_content_list_view.html#aa6c50404ec351a94408ef289c62032f5", null ]
];