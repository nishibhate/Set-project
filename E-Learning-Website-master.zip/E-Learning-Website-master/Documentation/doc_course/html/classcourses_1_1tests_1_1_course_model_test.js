var classcourses_1_1tests_1_1_course_model_test =
[
    [ "setUp", "classcourses_1_1tests_1_1_course_model_test.html#adf01411551988dc115fe27aa8919aa3a", null ],
    [ "test_course_content", "classcourses_1_1tests_1_1_course_model_test.html#aa590ed3e4020982486beb2aad50b11f3", null ],
    [ "test_student_field", "classcourses_1_1tests_1_1_course_model_test.html#a48ad111af0a198ed228a266dd25e7e9f", null ],
    [ "test_subject_content", "classcourses_1_1tests_1_1_course_model_test.html#a319f855c5c97d83fc03d3deeb33ba2b9", null ],
    [ "test_user", "classcourses_1_1tests_1_1_course_model_test.html#a870653c999493421bf3f7b49fa647dca", null ],
    [ "course1", "classcourses_1_1tests_1_1_course_model_test.html#a1c37c1960a32a266d90b64ee51e1acd8", null ],
    [ "sub1", "classcourses_1_1tests_1_1_course_model_test.html#a1abd865082befc1f2a25ab2895abc232", null ],
    [ "u1", "classcourses_1_1tests_1_1_course_model_test.html#a9aaf67ba044f847815c064826231e5d1", null ],
    [ "u2", "classcourses_1_1tests_1_1_course_model_test.html#a91b7015095aed553a44b96f9e29fb447", null ]
];