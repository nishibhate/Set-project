var classcourses_1_1views_1_1_owner_mixin =
[
    [ "get_querysset", "classcourses_1_1views_1_1_owner_mixin.html#aad5d85ef336fdaaebe6bc7bcd23f8a53", null ]
];