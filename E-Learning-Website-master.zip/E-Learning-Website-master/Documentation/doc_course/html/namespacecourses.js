var namespacecourses =
[
    [ "admin", "namespacecourses_1_1admin.html", "namespacecourses_1_1admin" ],
    [ "apps", "namespacecourses_1_1apps.html", "namespacecourses_1_1apps" ],
    [ "fields", "namespacecourses_1_1fields.html", "namespacecourses_1_1fields" ],
    [ "models", "namespacecourses_1_1models.html", "namespacecourses_1_1models" ],
    [ "tests", "namespacecourses_1_1tests.html", "namespacecourses_1_1tests" ],
    [ "views", "namespacecourses_1_1views.html", "namespacecourses_1_1views" ]
];