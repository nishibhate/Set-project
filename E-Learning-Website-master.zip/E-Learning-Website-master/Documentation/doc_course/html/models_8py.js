var models_8py =
[
    [ "Subject", "classcourses_1_1models_1_1_subject.html", "classcourses_1_1models_1_1_subject" ],
    [ "Meta", "classcourses_1_1models_1_1_subject_1_1_meta.html", null ],
    [ "Course", "classcourses_1_1models_1_1_course.html", null ],
    [ "Meta", "classcourses_1_1models_1_1_meta.html", null ],
    [ "Module", "classcourses_1_1models_1_1_module.html", "classcourses_1_1models_1_1_module" ],
    [ "Meta", "classcourses_1_1models_1_1_module_1_1_meta.html", null ],
    [ "Content", "classcourses_1_1models_1_1_content.html", "classcourses_1_1models_1_1_content" ],
    [ "Meta", "classcourses_1_1models_1_1_content_1_1_meta.html", null ],
    [ "ItemBase", "classcourses_1_1models_1_1_item_base.html", "classcourses_1_1models_1_1_item_base" ],
    [ "Meta", "classcourses_1_1models_1_1_item_base_1_1_meta.html", null ],
    [ "Text", "classcourses_1_1models_1_1_text.html", null ],
    [ "File", "classcourses_1_1models_1_1_file.html", null ],
    [ "Image", "classcourses_1_1models_1_1_image.html", null ],
    [ "Video", "classcourses_1_1models_1_1_video.html", null ],
    [ "__str__", "models_8py.html#a868c47ac4163f22a9e2e9f3d767e36d7", null ]
];