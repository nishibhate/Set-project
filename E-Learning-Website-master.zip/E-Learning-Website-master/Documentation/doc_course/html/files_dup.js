var files_dup =
[
    [ "__init__.py", "____init_____8py.html", null ],
    [ "admin.py", "admin_8py.html", [
      [ "SubjectAdmin", "classcourses_1_1admin_1_1_subject_admin.html", null ],
      [ "ModuleInline", "classcourses_1_1admin_1_1_module_inline.html", null ],
      [ "CourseAdmin", "classcourses_1_1admin_1_1_course_admin.html", null ]
    ] ],
    [ "apps.py", "apps_8py.html", [
      [ "CoursesConfig", "classcourses_1_1apps_1_1_courses_config.html", null ]
    ] ],
    [ "fields.py", "fields_8py.html", [
      [ "OrderField", "classcourses_1_1fields_1_1_order_field.html", "classcourses_1_1fields_1_1_order_field" ]
    ] ],
    [ "forms.py", "forms_8py.html", "forms_8py" ],
    [ "models.py", "models_8py.html", "models_8py" ],
    [ "tests.py", "tests_8py.html", [
      [ "CourseModelTest", "classcourses_1_1tests_1_1_course_model_test.html", "classcourses_1_1tests_1_1_course_model_test" ],
      [ "CoursePageViewTest", "classcourses_1_1tests_1_1_course_page_view_test.html", "classcourses_1_1tests_1_1_course_page_view_test" ]
    ] ],
    [ "urls.py", "urls_8py.html", "urls_8py" ],
    [ "views.py", "views_8py.html", "views_8py" ]
];