var namespacecourses_1_1models =
[
    [ "Content", "classcourses_1_1models_1_1_content.html", "classcourses_1_1models_1_1_content" ],
    [ "Course", "classcourses_1_1models_1_1_course.html", null ],
    [ "File", "classcourses_1_1models_1_1_file.html", null ],
    [ "Image", "classcourses_1_1models_1_1_image.html", null ],
    [ "ItemBase", "classcourses_1_1models_1_1_item_base.html", "classcourses_1_1models_1_1_item_base" ],
    [ "Meta", "classcourses_1_1models_1_1_meta.html", null ],
    [ "Module", "classcourses_1_1models_1_1_module.html", "classcourses_1_1models_1_1_module" ],
    [ "Subject", "classcourses_1_1models_1_1_subject.html", "classcourses_1_1models_1_1_subject" ],
    [ "Text", "classcourses_1_1models_1_1_text.html", null ],
    [ "Video", "classcourses_1_1models_1_1_video.html", null ]
];