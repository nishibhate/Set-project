var namespacecourses_1_1tests =
[
    [ "CourseModelTest", "classcourses_1_1tests_1_1_course_model_test.html", "classcourses_1_1tests_1_1_course_model_test" ],
    [ "CoursePageViewTest", "classcourses_1_1tests_1_1_course_page_view_test.html", "classcourses_1_1tests_1_1_course_page_view_test" ]
];