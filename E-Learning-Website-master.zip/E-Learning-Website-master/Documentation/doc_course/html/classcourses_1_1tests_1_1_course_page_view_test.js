var classcourses_1_1tests_1_1_course_page_view_test =
[
    [ "setup", "classcourses_1_1tests_1_1_course_page_view_test.html#a9a0d63ebc4cd50302f04b60c7dcc7de3", null ],
    [ "test_view_url_exists_at_proper_location", "classcourses_1_1tests_1_1_course_page_view_test.html#ad6875be887c9f167d99ae3ec6267de78", null ],
    [ "test_view_uses_correct_templates", "classcourses_1_1tests_1_1_course_page_view_test.html#ab67e570a7487212848fc239c5aa85f18", null ],
    [ "course1", "classcourses_1_1tests_1_1_course_page_view_test.html#af43b748360fae7814e0c504f96b7407c", null ],
    [ "sub1", "classcourses_1_1tests_1_1_course_page_view_test.html#ad87782df0950a5be8da344fa102906e6", null ],
    [ "u1", "classcourses_1_1tests_1_1_course_page_view_test.html#a71005eb4cac8ad89f812b304608c9e50", null ],
    [ "u2", "classcourses_1_1tests_1_1_course_page_view_test.html#ac15c19dd7cb0f8d65cfc626185b80024", null ]
];