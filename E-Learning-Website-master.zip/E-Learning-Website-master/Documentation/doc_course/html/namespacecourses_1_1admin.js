var namespacecourses_1_1admin =
[
    [ "CourseAdmin", "classcourses_1_1admin_1_1_course_admin.html", null ],
    [ "ModuleInline", "classcourses_1_1admin_1_1_module_inline.html", null ],
    [ "SubjectAdmin", "classcourses_1_1admin_1_1_subject_admin.html", null ]
];