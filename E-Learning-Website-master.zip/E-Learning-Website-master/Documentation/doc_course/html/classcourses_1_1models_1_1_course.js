var classcourses_1_1models_1_1_course =
[
    [ "Meta", "classcourses_1_1models_1_1_course_1_1_meta.html", null ],
    [ "__str__", "classcourses_1_1models_1_1_course.html#a000b8ecd933ad984d0839aab3e60ac77", null ]
];