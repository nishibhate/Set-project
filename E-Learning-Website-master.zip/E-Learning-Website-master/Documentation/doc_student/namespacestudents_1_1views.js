var namespacestudents_1_1views =
[
    [ "StudentCourseDetailView", "classstudents_1_1views_1_1_student_course_detail_view.html", "classstudents_1_1views_1_1_student_course_detail_view" ],
    [ "StudentCourseListView", "classstudents_1_1views_1_1_student_course_list_view.html", "classstudents_1_1views_1_1_student_course_list_view" ],
    [ "StudentEnrollCourseView", "classstudents_1_1views_1_1_student_enroll_course_view.html", "classstudents_1_1views_1_1_student_enroll_course_view" ],
    [ "StudentRegistrationView", "classstudents_1_1views_1_1_student_registration_view.html", "classstudents_1_1views_1_1_student_registration_view" ]
];