var files_dup =
[
    [ "__init__.py", "____init_____8py.html", null ],
    [ "admin.py", "admin_8py.html", null ],
    [ "apps.py", "apps_8py.html", [
      [ "StudentsConfig", "classstudents_1_1apps_1_1_students_config.html", null ]
    ] ],
    [ "forms.py", "forms_8py.html", [
      [ "CourseEnrollForm", "classstudents_1_1forms_1_1_course_enroll_form.html", null ]
    ] ],
    [ "helpers.py", "helpers_8py.html", "helpers_8py" ],
    [ "models.py", "models_8py.html", null ],
    [ "test_functions.py", "test__functions_8py.html", "test__functions_8py" ],
    [ "tests.py", "tests_8py.html", null ],
    [ "tl.py", "tl_8py.html", null ],
    [ "urls.py", "urls_8py.html", "urls_8py" ],
    [ "views.py", "views_8py.html", [
      [ "StudentRegistrationView", "classstudents_1_1views_1_1_student_registration_view.html", "classstudents_1_1views_1_1_student_registration_view" ],
      [ "StudentEnrollCourseView", "classstudents_1_1views_1_1_student_enroll_course_view.html", "classstudents_1_1views_1_1_student_enroll_course_view" ],
      [ "StudentCourseListView", "classstudents_1_1views_1_1_student_course_list_view.html", "classstudents_1_1views_1_1_student_course_list_view" ],
      [ "StudentCourseDetailView", "classstudents_1_1views_1_1_student_course_detail_view.html", "classstudents_1_1views_1_1_student_course_detail_view" ]
    ] ]
];