var test__functions_8py =
[
    [ "Tests", "classstudents_1_1test__functions_1_1_tests.html", "classstudents_1_1test__functions_1_1_tests" ],
    [ "print_fail", "test__functions_8py.html#a9cdccd370add2569257d32914432a68b", null ],
    [ "print_pass", "test__functions_8py.html#a548d4d8c1d685e1e23f3bc6491791134", null ],
    [ "printmd", "test__functions_8py.html#ad7ec968b946a641aeac8a695aaf6c456", null ]
];