var classstudents_1_1views_1_1_student_course_detail_view =
[
    [ "get_context_data", "classstudents_1_1views_1_1_student_course_detail_view.html#a412395c065877fe448c1bc9fc33407c6", null ],
    [ "get_queryset", "classstudents_1_1views_1_1_student_course_detail_view.html#ae21743dc6f7d37200b04020dd6d5f7ff", null ]
];