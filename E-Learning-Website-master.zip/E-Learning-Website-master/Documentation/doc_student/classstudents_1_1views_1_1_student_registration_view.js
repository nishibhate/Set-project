var classstudents_1_1views_1_1_student_registration_view =
[
    [ "form_valid", "classstudents_1_1views_1_1_student_registration_view.html#a3581fcfa2cf502d83cbd66f611503c3f", null ]
];