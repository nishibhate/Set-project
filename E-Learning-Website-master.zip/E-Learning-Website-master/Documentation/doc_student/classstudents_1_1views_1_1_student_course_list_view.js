var classstudents_1_1views_1_1_student_course_list_view =
[
    [ "get_queryset", "classstudents_1_1views_1_1_student_course_list_view.html#aaad03b3e8d0dedaaf8382a3ea79c54f7", null ]
];