var classstudents_1_1views_1_1_student_enroll_course_view =
[
    [ "form_valid", "classstudents_1_1views_1_1_student_enroll_course_view.html#ad22b2f0994a0d9010793ad63939cba9c", null ],
    [ "get_success_url", "classstudents_1_1views_1_1_student_enroll_course_view.html#a14fd941aeb41dd8822b56be39690cd24", null ]
];