var urls_8py =
[
    [ "urlpatterns", "urls_8py.html#acb61ed1f8bc947bf03122bc212bbae62", null ]
];