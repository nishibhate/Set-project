var searchData=
[
  ['urlpatterns_43',['urlpatterns',['../namespacestudents_1_1urls.html#acb61ed1f8bc947bf03122bc212bbae62',1,'students::urls']]],
  ['urls_2epy_44',['urls.py',['../urls_8py.html',1,'']]]
];
