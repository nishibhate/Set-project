var searchData=
[
  ['urls_2epy_73',['urls.py',['../urls_8py.html',1,'']]]
];
