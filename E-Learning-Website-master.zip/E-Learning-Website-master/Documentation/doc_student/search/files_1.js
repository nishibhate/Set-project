var searchData=
[
  ['admin_2epy_65',['admin.py',['../admin_8py.html',1,'']]],
  ['apps_2epy_66',['apps.py',['../apps_8py.html',1,'']]]
];
