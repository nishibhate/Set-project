var searchData=
[
  ['form_5fclass_5',['form_class',['../classstudents_1_1views_1_1_student_registration_view.html#aaadaac03e4f3b3f7a439b2969101da1b',1,'students.views.StudentRegistrationView.form_class()'],['../classstudents_1_1views_1_1_student_enroll_course_view.html#aa2f06f2c80b8fe0f5bc7111d5d7f0bf8',1,'students.views.StudentEnrollCourseView.form_class()']]],
  ['form_5fvalid_6',['form_valid',['../classstudents_1_1views_1_1_student_registration_view.html#a3581fcfa2cf502d83cbd66f611503c3f',1,'students.views.StudentRegistrationView.form_valid()'],['../classstudents_1_1views_1_1_student_enroll_course_view.html#ad22b2f0994a0d9010793ad63939cba9c',1,'students.views.StudentEnrollCourseView.form_valid()']]],
  ['forms_2epy_7',['forms.py',['../forms_8py.html',1,'']]]
];
