var searchData=
[
  ['print_5ffail_80',['print_fail',['../namespacestudents_1_1test__functions.html#a9cdccd370add2569257d32914432a68b',1,'students::test_functions']]],
  ['print_5fpass_81',['print_pass',['../namespacestudents_1_1test__functions.html#a548d4d8c1d685e1e23f3bc6491791134',1,'students::test_functions']]],
  ['printmd_82',['printmd',['../namespacestudents_1_1test__functions.html#ad7ec968b946a641aeac8a695aaf6c456',1,'students::test_functions']]]
];
