var searchData=
[
  ['form_5fclass_86',['form_class',['../classstudents_1_1views_1_1_student_registration_view.html#aaadaac03e4f3b3f7a439b2969101da1b',1,'students.views.StudentRegistrationView.form_class()'],['../classstudents_1_1views_1_1_student_enroll_course_view.html#aa2f06f2c80b8fe0f5bc7111d5d7f0bf8',1,'students.views.StudentEnrollCourseView.form_class()']]]
];
