var searchData=
[
  ['load_5fdataset_12',['load_dataset',['../namespacestudents_1_1helpers.html#a0db947fa59d062a19c0678594cf5e489',1,'students::helpers']]]
];
