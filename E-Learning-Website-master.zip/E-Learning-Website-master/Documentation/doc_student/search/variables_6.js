var searchData=
[
  ['urlpatterns_91',['urlpatterns',['../namespacestudents_1_1urls.html#acb61ed1f8bc947bf03122bc212bbae62',1,'students::urls']]]
];
