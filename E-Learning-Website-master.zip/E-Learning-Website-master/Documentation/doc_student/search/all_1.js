var searchData=
[
  ['admin_2epy_1',['admin.py',['../admin_8py.html',1,'']]],
  ['apps_2epy_2',['apps.py',['../apps_8py.html',1,'']]]
];
