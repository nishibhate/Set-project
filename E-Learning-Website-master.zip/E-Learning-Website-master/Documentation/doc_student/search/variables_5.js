var searchData=
[
  ['template_5fname_90',['template_name',['../classstudents_1_1views_1_1_student_registration_view.html#a8a7abfb3c1ebcaf612189f4af9077422',1,'students.views.StudentRegistrationView.template_name()'],['../classstudents_1_1views_1_1_student_course_list_view.html#a2348bda5d40ed0d230c42c622f5c0586',1,'students.views.StudentCourseListView.template_name()'],['../classstudents_1_1views_1_1_student_course_detail_view.html#a7ee32dade8c7889384bc86e7f5c35d08',1,'students.views.StudentCourseDetailView.template_name()']]]
];
