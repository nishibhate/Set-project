var searchData=
[
  ['template_5fname_36',['template_name',['../classstudents_1_1views_1_1_student_registration_view.html#a8a7abfb3c1ebcaf612189f4af9077422',1,'students.views.StudentRegistrationView.template_name()'],['../classstudents_1_1views_1_1_student_course_list_view.html#a2348bda5d40ed0d230c42c622f5c0586',1,'students.views.StudentCourseListView.template_name()'],['../classstudents_1_1views_1_1_student_course_detail_view.html#a7ee32dade8c7889384bc86e7f5c35d08',1,'students.views.StudentCourseDetailView.template_name()']]],
  ['test_5ffunctions_2epy_37',['test_functions.py',['../test__functions_8py.html',1,'']]],
  ['test_5fone_5fhot_38',['test_one_hot',['../classstudents_1_1test__functions_1_1_tests.html#a91b96f9428d467a1461974eeb77aaa52',1,'students::test_functions::Tests']]],
  ['test_5fred_5fas_5fgreen_39',['test_red_as_green',['../classstudents_1_1test__functions_1_1_tests.html#ae1bac126024e901e1a1e7623d3cb722a',1,'students::test_functions::Tests']]],
  ['tests_40',['Tests',['../classstudents_1_1test__functions_1_1_tests.html',1,'students::test_functions']]],
  ['tests_2epy_41',['tests.py',['../tests_8py.html',1,'']]],
  ['tl_2epy_42',['tl.py',['../tl_8py.html',1,'']]]
];
