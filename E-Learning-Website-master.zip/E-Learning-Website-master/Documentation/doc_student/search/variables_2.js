var searchData=
[
  ['model_87',['model',['../classstudents_1_1views_1_1_student_course_list_view.html#a313ebc96dc6909ac135bf3dcb0b74c2d',1,'students.views.StudentCourseListView.model()'],['../classstudents_1_1views_1_1_student_course_detail_view.html#a2f5649fd3efb7641e7095e979959d164',1,'students.views.StudentCourseDetailView.model()']]]
];
