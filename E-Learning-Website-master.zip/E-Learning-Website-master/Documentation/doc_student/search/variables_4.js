var searchData=
[
  ['success_5furl_89',['success_url',['../classstudents_1_1views_1_1_student_registration_view.html#abd5863d4acf22906a286eb9600cb5e0b',1,'students::views::StudentRegistrationView']]]
];
