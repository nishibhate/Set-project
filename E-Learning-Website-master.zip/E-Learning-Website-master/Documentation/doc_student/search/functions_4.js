var searchData=
[
  ['test_5fone_5fhot_83',['test_one_hot',['../classstudents_1_1test__functions_1_1_tests.html#a91b96f9428d467a1461974eeb77aaa52',1,'students::test_functions::Tests']]],
  ['test_5fred_5fas_5fgreen_84',['test_red_as_green',['../classstudents_1_1test__functions_1_1_tests.html#ae1bac126024e901e1a1e7623d3cb722a',1,'students::test_functions::Tests']]]
];
