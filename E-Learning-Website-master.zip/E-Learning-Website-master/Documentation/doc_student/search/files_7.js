var searchData=
[
  ['views_2epy_74',['views.py',['../views_8py.html',1,'']]]
];
