var indexSectionsWithContent =
{
  0: "_acfghlmnpstuv",
  1: "cst",
  2: "s",
  3: "_afhmtuv",
  4: "fglpt",
  5: "cfmnstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

