var searchData=
[
  ['name_88',['name',['../classstudents_1_1apps_1_1_students_config.html#a4e4ab80e66eda5885d0635c3c87e54c8',1,'students::apps::StudentsConfig']]]
];
