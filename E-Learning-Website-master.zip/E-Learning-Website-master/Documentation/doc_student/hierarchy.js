var hierarchy =
[
    [ "Form", null, [
      [ "students.forms.CourseEnrollForm", "classstudents_1_1forms_1_1_course_enroll_form.html", null ]
    ] ],
    [ "TestCase", null, [
      [ "students.test_functions.Tests", "classstudents_1_1test__functions_1_1_tests.html", null ]
    ] ],
    [ "AppConfig", null, [
      [ "students.apps.StudentsConfig", "classstudents_1_1apps_1_1_students_config.html", null ]
    ] ],
    [ "CreateView", null, [
      [ "students.views.StudentRegistrationView", "classstudents_1_1views_1_1_student_registration_view.html", null ]
    ] ],
    [ "DetailView", null, [
      [ "students.views.StudentCourseDetailView", "classstudents_1_1views_1_1_student_course_detail_view.html", null ]
    ] ],
    [ "FormView", null, [
      [ "students.views.StudentEnrollCourseView", "classstudents_1_1views_1_1_student_enroll_course_view.html", null ]
    ] ],
    [ "ListView", null, [
      [ "students.views.StudentCourseListView", "classstudents_1_1views_1_1_student_course_list_view.html", null ]
    ] ],
    [ "LoginRequiredMixin", null, [
      [ "students.views.StudentCourseListView", "classstudents_1_1views_1_1_student_course_list_view.html", null ],
      [ "students.views.StudentEnrollCourseView", "classstudents_1_1views_1_1_student_enroll_course_view.html", null ]
    ] ]
];